$(function(){
  $('#q1').click(function(){
    var oldAns = $('.active-response');
    var newAns = $('#faq1');
    oldAns.removeClass('active-response');
    newAns.addClass('active-response');
  });
  $('#q2').click(function(){
    var oldAns = $('.active-response');
    var newAns = $('#faq2');
    oldAns.removeClass('active-response');
    newAns.addClass('active-response');
  });
  $('#q3').click(function(){
    var oldAns = $('.active-response');
    var newAns = $('#faq3');
    oldAns.removeClass('active-response');
    newAns.addClass('active-response');
  });
  $('#q4').click(function(){
    var oldAns = $('.active-response');
    var newAns = $('#faq4');
    oldAns.removeClass('active-response');
    newAns.addClass('active-response');
  });
  $('#q5').click(function(){
    var oldAns = $('.active-response');
    var newAns = $('#faq5');
    oldAns.removeClass('active-response');
    newAns.addClass('active-response');
  });
  $('#q6').click(function(){
    var oldAns = $('.active-response');
    var newAns = $('#faq6');
    oldAns.removeClass('active-response');
    newAns.addClass('active-response');
  });
  $('#q7').click(function(){
    var oldAns = $('.active-response');
    var newAns = $('#faq7');
    oldAns.removeClass('active-response');
    newAns.addClass('active-response');
  });
  $('#q8').click(function(){
    var oldAns = $('.active-response');
    var newAns = $('#faq8');
    oldAns.removeClass('active-response');
    newAns.addClass('active-response');
  });
  $('#q9').click(function(){
    var oldAns = $('.active-response');
    var newAns = $('#faq9');
    oldAns.removeClass('active-response');
    newAns.addClass('active-response');
  });
});
