$(document).ready(function () {
    $('#backdrop').queryLoader2();
});
